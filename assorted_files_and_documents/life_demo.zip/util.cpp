#include "util.h"
#include <QtGlobal>
#include <QTime>
std::mt19937 &RNG() {
    //seed mt with current time upon construction
    static std::mt19937 rng(QTime::currentTime().msec());
    return rng;
}
