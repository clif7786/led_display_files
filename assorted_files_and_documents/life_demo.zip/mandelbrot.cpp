#include <QTextEdit>
#include <QPushButton>
#include <QDebug>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSizePolicy>
#include <QSlider>
#include <QSpinBox>
#include <QLabel>
#include <QLineEdit>
#include <QDoubleValidator>
#include <QIntValidator>
#include <iostream>
#include <random>
#include <complex>
#include "pixel_window.h"
#include "mandelbrot.h"
#include "util.h"

mandelbrot::mandelbrot(pixel_window &window, QObject *parent)
: plugin(window, parent),
  hypnotoad_timer(new QTimer(this)),
  mandelbrot_buffer(window.w(), window.h(), buffer().format()),
  upper_x(-1.5), upper_y(-1), width(2),
  max_escape(10000),
  hypnotoad_offset(0),
  palette_buffer(window.w()*window.h())
{
    hypnotoad_timer->setInterval(250);
    connect(hypnotoad_timer, SIGNAL(timeout()), this, SLOT(hypnotoad_tick()));
}

QWidget *mandelbrot::make_widget() {
    QWidget *w = new QWidget;
    QVBoxLayout *l = new QVBoxLayout;

    /* text box for number of iterations */
    {
        QIntValidator *validator = new QIntValidator(w);
        QHBoxLayout *h_layout = new QHBoxLayout;
        QLabel *label = new QLabel("Iterations:");
        QLineEdit *line_edit = new QLineEdit(std::to_string(max_escape).c_str());
        line_edit->setValidator(validator);
        connect(line_edit, &QLineEdit::editingFinished, [this,line_edit]() {
            max_escape = line_edit->text().toDouble();
            calculate();
        });
        h_layout->addWidget(label);
        h_layout->addWidget(line_edit);
        l->addLayout(h_layout);
    }


    /* three text boxes for the three variables */
    {
        QDoubleValidator *validator = new QDoubleValidator(w);
        QHBoxLayout *h_layout = new QHBoxLayout;
        for(int i = 0; i < 3; i++) {
            double &var =   i == 0 ? upper_x
                          : i == 1 ? upper_y
                          :          width;
            QString label_text[] = {"x","y","w"};
            QLabel *label = new QLabel(label_text[i]);
            QString text[] = {"-1.5", "-1", "2"};
            QLineEdit *line_edit = new QLineEdit(text[i]);
            line_edit->setValidator(validator);
            connect(line_edit, &QLineEdit::editingFinished, [this,line_edit,&var]() {
                var = line_edit->text().toDouble();
                calculate();
            });
            h_layout->addWidget(label);
            h_layout->addWidget(line_edit);
            if(i == 1) {
                l->addLayout(h_layout);
                h_layout = new QHBoxLayout;
            }
            if(i == 2)
                l->addLayout(h_layout);
        }
    }

    checkbox = new QCheckBox("ALL GLORY TO THE HYPNOTOAD");
    connect(checkbox, SIGNAL(stateChanged(int)), this, SLOT(toggle_hypnotoad(int)));
    l->addWidget(checkbox);
    w->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    w->setLayout(l);
    return w;
}

void mandelbrot::calculate() {
    std::vector<int> escapes(window.h()*window.w()),
                     color_histogram(max_escape);
    unsigned long color_total = 0;

    const double w = width;
    const double h = width;
    for(int y = 0; y < window.h(); y++)
    for(int x = 0; x < window.w(); x++) {
        const double y_pos = upper_y + h*double(y)/window.h();
        const double x_pos = upper_x + w*double(x)/window.w();
        const int val = escape(y_pos,x_pos,max_escape);
        escapes[y*window.w()+x] = val;
        if(val != max_escape) {
            color_histogram[val]++;
            color_total++;
        }
    }
    for(int y = 0; y < window.h(); y++)
    for(int x = 0; x < window.w(); x++) {
        int velocity = escapes[y*window.w()+x];
        if(velocity == max_escape)
            palette_buffer[y*window.w()+x] = 0;
        else {
            double hue = 0;
            for(int i = 0; i <= velocity; i++)
                hue += double(color_histogram[i]) / color_total;
            palette_buffer[y*window.w()+x] = 1 + int(hue*7);
        }
    }
    render();
}

void mandelbrot::render() {
    QRgb colors[] = {0xFF0000FF, //001
                     0xFF00FFFF, //011
                     0xFF00FF00, //010
                     0xFFFFFF00, //110
                     0xFFFF0000, //100
                     0xFFFF00FF, //101
                     0xFFFFFFFF};
    for(int y = 0; y < window.h(); y++)
    for(int x = 0; x < window.w(); x++) {
        int color = palette_buffer[y*window.w()+x];
        if(color == 0)
            mandelbrot_buffer.setPixel(x,y,0xFF000000);
        else {
            color = (color - 1 + hypnotoad_offset) % 7;
            mandelbrot_buffer.setPixel(x,y,colors[color]);
        }
    }
    buffer().swap(mandelbrot_buffer);
    window.repaint();
}

void mandelbrot::hypnotoad_tick() {
    hypnotoad_offset++;
    render();
}

void mandelbrot::toggle_hypnotoad(int on) {
    if(on)
        hypnotoad_timer->start();
    else
        hypnotoad_timer->stop();
}

int mandelbrot::escape(double y, double x, int max_val) const {
    std::complex<double> z(0,0);
    std::complex<double> c(x,y);

    /* check easily computed positions */
    double q = (x-.25)*(x-.25)+y*y;
    if(q*(q+(x-.25)) < (.25*y*y))
        return max_val;
    if( (x+1)*(x+1) + y*y < 1.0/16.0)
        return max_val;

    /* do escape analysis */
    for(int i = 0; i < max_val; i++) {
        std::complex<double> znew = z*z + c;
        if(znew == z)
            return max_val;
        z = znew;
        if(std::norm(z) >= 4)
            return i;
    }
    return max_val;
}

void mandelbrot::start() {
    if(mandelbrot_buffer.width() != buffer().width()) {
        QImage new_buffer(window.w(), window.h(), buffer().format());
        mandelbrot_buffer.swap(new_buffer);
        palette_buffer.resize(window.height()*window.width());
    }
    calculate();
}

void mandelbrot::stop() {
    checkbox->setChecked(false);
}

QString mandelbrot::name() { return "Mandelbrot"; }

