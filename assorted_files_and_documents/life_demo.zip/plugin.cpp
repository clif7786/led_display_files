#include "plugin.h"

plugin::plugin(QObject *parent) : QObject(parent)
{}

plugin::~plugin()
{}

