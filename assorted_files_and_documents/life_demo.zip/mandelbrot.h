#ifndef MANDELBROT_H
#define MANDELBROT_H

#include <QObject>
#include <QTimer>
#include <QImage>
#include <QCheckBox>
#include "plugin.h"

class mandelbrot : public plugin {
    Q_OBJECT
    QTimer *hypnotoad_timer;
    QImage mandelbrot_buffer;
    double upper_x, upper_y, width;
    int max_escape;
    int hypnotoad_offset;
    std::vector<int> palette_buffer;
    QCheckBox *checkbox;
public:
    explicit mandelbrot(pixel_window &window, QObject *parent = 0);

    QWidget *make_widget();
    void start();
    void stop();
    QString name();

private:
    int escape(double y, double x, int max) const;
    void calculate();
    void render();
    QRgb color(int escape_velocity) const;
private slots:
    void toggle_hypnotoad(int on);
    void hypnotoad_tick();
};

#endif // COLOR_LIFE_H
