#ifndef COLOR_LIFE_H
#define COLOR_LIFE_H

#include <QObject>
#include <QTimer>
#include "plugin.h"

enum class COLOR { RED = 0, GREEN = 1, BLUE = 2 };
class color_life : public plugin {
    Q_OBJECT
    QImage life_buffer;
    QTimer timer;
    double color_prob[3];
public:
    explicit color_life(pixel_window &window, QObject *parent = 0);

    QWidget *make_widget();
    void start();
    void stop();
    QString name();
public slots:
    void update();
    void reset();
private:
    int neighbors(int y, int x, COLOR c) const;
    bool alive(int y, int x, COLOR c) const;
    QRgb random_color() const;
    int color_mask(COLOR c) const;
};

#endif // COLOR_LIFE_H
