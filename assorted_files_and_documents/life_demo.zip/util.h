#ifndef UTIL_H
#define UTIL_H

#include <random>

//NOT thread safe
std::mt19937 &RNG();

#endif // UTIL_H

