#include "pixel_window.h"

#include <QPainter>
#include <utility>

pixel_window::pixel_window(int pix_x, int pix_y, int x, int y, QWidget *parent)
: QWidget(parent),
  pix_x(pix_x), pix_y(pix_y), x(x), y(y),
  buffer(pix_x,pix_y,QImage::Format_RGB888)
{
    buffer.fill(0);
    setWindowFlags(Qt::FramelessWindowHint);
    resize(x+pix_x,std::max(y,pix_y));
    move(0,0);
}

pixel_window::~pixel_window() {}

void pixel_window::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    painter.fillRect(0,pix_y,pix_x,y-pix_y,QColor(0,0,0,255));
    painter.drawImage(QRect(0,0,pix_x,pix_y), buffer);
    painter.drawImage(QRect(pix_x,0,x,y), buffer);
}

int pixel_window::w() const { return pix_x; }
int pixel_window::h() const { return pix_y; }

void pixel_window::change_width(int width) {
    pix_x = width;
    pix_y = width;
    QImage new_buffer(pix_x,pix_y,QImage::Format_RGB888);
    buffer.swap(new_buffer);
    buffer.fill(0);
    resize(x+pix_x,std::max(y,pix_y));
}
void pixel_window::change_scale(int scale_width) {
    x = scale_width;
    y = scale_width;
    resize(x+pix_x,std::max(y,pix_y));
    repaint();
}
