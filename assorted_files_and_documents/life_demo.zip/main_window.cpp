#include "main_window.h"

main_window::main_window(QWidget *parent)
: QMainWindow(parent),
  textbox(new QTextEdit(this))
{
    pixel_out.show();
}

main_window::~main_window()
{

}

