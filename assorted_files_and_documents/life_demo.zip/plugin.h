#ifndef PLUGIN_H
#define PLUGIN_H

#include <QObject>
#include <QWidget>
#include <QDebug>
#include "pixel_window.h"

class plugin : public QObject
{
    Q_OBJECT
protected:
    /* output pixel window to draw to */
    pixel_window &window;
public:
    explicit plugin(pixel_window &window, QObject *parent = 0)
    : QObject(parent), window(window)
    {}

    ~plugin() {}

    /* returns a widget that the GUI will display.
     * The plugin can connect events to the widget before returning it
     * to get information back from the GUI
     */
    virtual QWidget *make_widget() { return 0; };

    /* When start is called the plugin is allowed to modify
     * the output window
     */
    virtual void start() {};

    /* when stop is called the plugin should stop modifying the
     * output window
     */
    virtual void stop() {};

    virtual QString name() { return "HELLO"; };

    /* convenience function for getting the window's QImage buffer */
    QImage &buffer() const {
        return window.buffer;
    }
};

#endif // PLUGIN_H
