#include <QTextEdit>
#include <QPushButton>
#include <QDebug>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSizePolicy>
#include <QSlider>
#include <QSpinBox>
#include <QLabel>
#include <iostream>
#include <random>
#include "pixel_window.h"
#include "color_life.h"
#include "util.h"

color_life::color_life(pixel_window &window, QObject *parent)
: plugin(window, parent),
  life_buffer(window.w(), window.h(), buffer().format()),
  timer(this),
  color_prob{0.3,0.3,0.3}
{}

QWidget *color_life::make_widget() {
    QVBoxLayout *l = new QVBoxLayout;

    /* Color sliders */
    for(COLOR c : {COLOR::RED, COLOR::GREEN, COLOR::BLUE}) {
        int i = static_cast<int>(c);
        QHBoxLayout *slider_layout = new QHBoxLayout;

        QString color_text[] = {"R", "G", "B"};
        QLabel *label = new QLabel(color_text[i]);
        slider_layout->addWidget(label);

        QSlider *slider = new QSlider(Qt::Horizontal);
        slider->setRange(0,100);
        slider->setSliderPosition(color_prob[i]*100);
        connect(slider, &QSlider::valueChanged, [this,i](int arg) {
            color_prob[i] = arg/100.0;
        });
        slider_layout->addWidget(slider);

        l->addLayout(slider_layout);
    }

    /* Speed box */
    QSpinBox *spinner = new QSpinBox;
    spinner->setSuffix("ms");
    spinner->setRange(0,10000);
    spinner->setSingleStep(1);
    spinner->setValue(100);
    timer.setInterval(100);

    connect(spinner, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged),
            [this](int arg)
    {
        timer.setInterval(arg);
    });
    l->addWidget(spinner);

    /* Reset button */
    QPushButton *reset_button = new QPushButton("Reset");
    connect(reset_button, SIGNAL(clicked()), this, SLOT(reset()));
    l->addWidget(reset_button);

    QWidget *w = new QWidget;
    w->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    w->setLayout(l);
    return w;
}

void color_life::start() {
    QImage new_buffer(window.w(), window.h(), buffer().format());
    life_buffer.swap(new_buffer);
    life_buffer.fill(0);
    reset();
    connect(&timer, SIGNAL(timeout()), this, SLOT(update()));
    timer.start();
};

void color_life::stop() {
    disconnect(&timer, 0, 0, 0);
    timer.stop();
};

void color_life::reset() {
     auto &rng = RNG();
     std::uniform_real_distribution<double> dist(0,1);
     for(int y = 0; y < window.h(); y++)
     for(int x = 0; x < window.w(); x++) {
         QRgb pixel_color = 0xFF000000;
         for(int color = 0; color < 3; color++) {
             double r = dist(rng);
             if(r < color_prob[color])
                 pixel_color |= color_mask(static_cast<COLOR>(color));
         }
         life_buffer.setPixel(x,y,pixel_color);
     }
     buffer().swap(life_buffer);
     window.repaint();
}

QRgb color_life::random_color() const {
    auto &rng = RNG();
    std::uniform_int_distribution<int> dist(0,6);
    QRgb lookup[] = {0xFF0000FF, 0xFF00FF00, 0xFFFF0000,
                     0xFF00FFFF, 0xFFFF00FF, 0xFFFFFF00,
                     0xFFFFFFFF};
    return lookup[dist(rng)];
}

int color_life::neighbors(int y, int x, COLOR c) const {
    int count = 0;
    for(int yd : {-1,0,1})
    for(int xd : {-1,0,1}) {
        if(!xd and !yd)
            continue;
        //assume window dimensions for speed
        const int ypos = (y+yd+window.h())%window.h();
        const int xpos = (x+xd+window.w())%window.w();
        count += alive(ypos,xpos, c);
    }
    return count;
}

bool color_life::alive(int y, int x, COLOR c) const {
    return buffer().pixel(y,x) & color_mask(c);
}

int color_life::color_mask(COLOR c) const {
    int mask =   (c == COLOR::RED)   ? 0xFF0000
               : (c == COLOR::GREEN) ? 0x00FF00
               : (c == COLOR::BLUE)  ? 0x0000FF : 0;
    return mask;
}

void color_life::update() {
    for(int y = 0; y < window.h(); y++)
    for(int x = 0; x < window.w(); x++) {
        QRgb color = 0xFF000000;
        for(COLOR c : {COLOR::RED, COLOR::GREEN, COLOR::BLUE}) {
            const int n = neighbors(y,x,c);
            const bool live = alive(y,x,c) ? (n == 2 || n == 3)
                                           : (n == 3);
            if(live) color |= color_mask(c);
        }
        life_buffer.setPixel(y,x,color);
    }
    buffer().swap(life_buffer);
    window.repaint();
}

QString color_life::name() { return "Life"; }
