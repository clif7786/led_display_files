#ifndef MAIN_WINDOW_H
#define MAIN_WINDOW_H

#include <QLabel>
#include <QMainWindow>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QApplication>
#include <QComboBox>
#include <QStackedWidget>
#include <QSpinBox>
#include <memory>
#include <iostream>
#include "pixel_window.h"
#include "color_life.h"
#include "mandelbrot.h"

class main_window : public QWidget
{
    Q_OBJECT

    pixel_window pixel_out;
    std::vector<plugin *> plugins;
    QComboBox *combobox;
    int current_plugin;
public:
    explicit main_window(QWidget *parent = 0)
    : QWidget(parent), pixel_out(32,32,256,256)
    {
        QVBoxLayout *layout = new QVBoxLayout;
        QStackedWidget *stack = new QStackedWidget;

        /* window options */
        QSpinBox *pixel_spinner = new QSpinBox;
        pixel_spinner->setSuffix("px");
        pixel_spinner->setRange(16,96);
        pixel_spinner->setSingleStep(1);
        pixel_spinner->setValue(32);

        QSpinBox *scale_spinner = new QSpinBox;
        scale_spinner->setSuffix("px");
        scale_spinner->setRange(16,640);
        scale_spinner->setSingleStep(1);
        scale_spinner->setValue(256);

        connect(pixel_spinner, SIGNAL(valueChanged(int)), &pixel_out, SLOT(change_width(int)));
        connect(pixel_spinner, SIGNAL(valueChanged(int)), this, SLOT(restart_plugin()));
        connect(scale_spinner, SIGNAL(valueChanged(int)), &pixel_out, SLOT(change_scale(int)));

        layout->addWidget(new QLabel("Native Width:"));
        layout->addWidget(pixel_spinner);
        layout->addWidget(new QLabel("Scaled Width:"));
        layout->addWidget(scale_spinner);

        /* set up plugins */
        combobox = new QComboBox;
        layout->addWidget(combobox);

        plugins.emplace_back(new mandelbrot(pixel_out, this));
        plugins.emplace_back(new color_life(pixel_out, this));
        for(plugin *p : plugins) {
            stack->addWidget(p->make_widget());
            combobox->addItem(p->name());
        }
        //stack->setFixedSize(300,500);
        layout->addWidget(stack);

        connect(combobox, SIGNAL(activated(int)), stack, SLOT(setCurrentIndex(int)));
        connect(stack, &QStackedWidget::currentChanged, [this](int i) {
            plugins[current_plugin]->stop();
            current_plugin = i;
            plugins[i]->start();
        });

        plugins[0]->start();
        current_plugin = 0;

        layout->setSizeConstraint(QLayout::SetMinAndMaxSize);
        setLayout(layout);
        pixel_out.show();
    }

    ~main_window() {};

    QSize sizeHint() const {
        return {300,500};
    }

    void closeEvent(QCloseEvent *) {
        qApp->quit();
    }
public slots:
    void restart_plugin() {
        plugins[current_plugin]->stop();
        plugins[current_plugin]->start();
    }

signals:
};

#endif // MAIN_WINDOW_H
