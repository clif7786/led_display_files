#ifndef MBLIT_PIXEL_WINDOW_H
#define MBLIT_PIXEL_WINDOW_H

#include <QWidget>
#include <QImage>

class pixel_window : public QWidget
{
    Q_OBJECT
    int pix_x;
    int pix_y;
    int x;
    int y;
protected:
    void paintEvent(QPaintEvent *event);
public:
    QImage buffer;
    explicit pixel_window(int pix_x, int pix_y, int x, int y, QWidget *parent = 0);
    ~pixel_window();

    int w() const;
    int h() const;
public slots:
    void change_width(int width);
    void change_scale(int scale_width);
};

#endif
